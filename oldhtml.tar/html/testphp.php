<html>
<?php
	echo "<title>PhP Test Page</title>\n";
?>
<body bgcolor="#FFFFFF">

<?php
	echo "<p>Testing that php works</p>\n";

?>


</body>
</html>

